import string
import re
from collections import Counter


def delete_char(inputWord):
    output = []
    for i in range(len(inputWord)):
        output.append(inputWord[:i] + inputWord[i+1:])
    return output

def switch_char(inputWord):
    output = []
    for i in range(len(inputWord) - 1):
        switched = inputWord[:i] + inputWord[i+1] + inputWord[i] + inputWord[i+2:]
        output.append(switched)
    return output

def replace_char(inputWord):
    output = []
    for i in range(len(inputWord)):
        for char in string.ascii_lowercase:
            if char != inputWord[i]:
                replaced = inputWord[:i] + char + inputWord[i+1:]
                output.append(replaced)
    return output

def insert_char(inputWord):
    output = []
    for i in range(len(inputWord) + 1):
        for char in string.ascii_lowercase:
            inserted = inputWord[:i] + char + inputWord[i:]
            output.append(inserted)
    return output

print(delete_char('pace'))   # ['ace', 'pce', 'pae', 'pac']
print(switch_char('eta'))    # ['tea', 'eat']
print(replace_char('can'))   # A list of 78 possible replacements
print(insert_char('at'))     # A list of 78 possible insertions


#PART 2
print("\nPart 2: \n")
def edit_distance_one(inputWord, allow_switches=False):

    edits = set()
    
    # Deletions
    edits.update(delete_char(inputWord))
    
    # Replacements
    edits.update(replace_char(inputWord))
    
    # Insertions
    edits.update(insert_char(inputWord))
    
    # Switches (optional)
    if allow_switches:
        edits.update(switch_char(inputWord))
    
    return edits


def edit_distance_two(inputWord, allow_switches=False):

    edits_one = edit_distance_one(inputWord, allow_switches)
    edits_two = set()
    
    for edit in edits_one:
        edits_two.update(edit_distance_one(edit, allow_switches))
    
    return edits_one.union(edits_two)


print("\nSwitches: False\n")
print(edit_distance_one('at', allow_switches=False))


print("\nSwitches: True\n")
print(edit_distance_one('at', allow_switches=True))


print("\nEdit distance two\n")
output = edit_distance_two('a', allow_switches=False)
print(f"Number of strings with edit distance of two: {len(output)}")
print(f"First 10 strings: {sorted(list(output))[:10]}")
print(f"Last 10 strings: {sorted(list(output))[-10:]}")

# PART 3
print("\nPART3: \n")

def Your_Read_Function(file_path):
    with open(file_path, 'r') as file:
        text = file.read()

    inputWords = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    vocab = Counter(inputWords) 
    return vocab


def probability_of_inputWord(inputWord, vocab, total_inputWord_count):
    return vocab[inputWord] / total_inputWord_count if inputWord in vocab else 0


def fix_edits(inputWord, vocab, allow_switches=False, n=5):
    total_inputWord_count = sum(vocab.values())
    
    if inputWord in vocab:
        return [(inputWord, probability_of_inputWord(inputWord, vocab, total_inputWord_count))]
    
    suggestions_one = edit_distance_one(inputWord, allow_switches).intersection(vocab)
    
    if suggestions_one:
        best_inputWords = {w: probability_of_inputWord(w, vocab, total_inputWord_count) for w in suggestions_one}
    else:

        suggestions_two = edit_distance_two(inputWord, allow_switches).intersection(vocab)
        
        if suggestions_two:
            best_inputWords = {w: probability_of_inputWord(w, vocab, total_inputWord_count) for w in suggestions_two}
        else:

            return [(inputWord, 0)]
    
    best_suggestions = Counter(best_inputWords).most_common(n)
    return best_suggestions


vocab = Your_Read_Function('shakespeare.txt')

inputWord = 'dys'
suggestions = fix_edits(inputWord, vocab, allow_switches=False, n=5)

print(f"\nEntered inputWord: {inputWord}\n")
for i, (suggestion, prob) in enumerate(suggestions):
    print(f"\ninputWord {i}: {suggestion}, probability {prob:.6f}\n")